from django.apps import AppConfig


class NikitaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nikita'
